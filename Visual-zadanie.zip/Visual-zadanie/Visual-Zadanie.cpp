#include <iostream>
#include <string>
#include <iomanip>
#include <chrono>
#include <ctime>

using namespace std;

int main() {
    string imie, nazwisko, zainteresowania;
    int wiek;

    system("color 0B");

    
    auto czas = chrono::system_clock::to_time_t(chrono::system_clock::now());
    tm *czas_tm = localtime(&czas);
    
    system("color 0B");

    cout << "\n\n\t\t\t Dane osobowe \n\n";
    cout << "\tPodaj imie: ";
    getline(cin, imie);
    cout << "\tPodaj nazwisko: ";
    getline(cin, nazwisko);
    cout << "\tPodaj wiek: ";
    cin >> wiek;
    cin.ignore(); 
    cout << "\tPodaj zainteresowania: ";
    getline(cin, zainteresowania);

    cout << "\n\n\t\t\t Podsumowanie: \n";
    cout << "\t-------------------------------\n";
    cout << "\tImie: " << imie << endl;
    cout << "\tNazwisko: " << nazwisko << endl;
    cout << "\tWiek: " << wiek << endl;
    cout << "\tZainteresowania: " << zainteresowania << endl;
    cout << "\t-------------------------------\n";

    
    cout << "\tAktualny czas: " 
         << put_time(czas_tm, "%H:%M:%S") << endl;
    cout << "\n\t\tKacper-168936\n\n";

    system("pause"); 

    return 0;
}